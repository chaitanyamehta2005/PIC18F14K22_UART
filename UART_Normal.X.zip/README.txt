Extract the ZIP file
Open the folder as a project of MPLAB


MPLAB Details:
Product Version: MPLAB X IDE v5.10
Java: 1.8.0_181; Java HotSpot(TM) 64-Bit Server VM 25.181-b13
Runtime: Java(TM) SE Runtime Environment 1.8.0_181-b13
System: Windows 7 version 6.1 running on amd64; Cp1252; en_US (mplab)
User directory: C:\Users\Chaitanya\AppData\Roaming\mplab_ide\dev\v5.10
Cache directory: C:\Users\Chaitanya\AppData\Local\mplab_ide\Cache\dev\v5.10\var

Steps already taken for this code for PIC18F14k22:
->Create new Project in MPLAB
->Using MCC Plugin of MPLAB,configure the EUSART and PIN/Clock related configuration.
->Generate the config file
->define a variable and only write the main code related lines in the main.c
->Generate the hex using the Production--->Build
->Load the Hex in to the MCU using the Pikkit
